require("dotenv").config();
const path = require("path");
const fs = require("fs");
const express = require("express");
const helmet = require("helmet");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const crypto = require("crypto");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const SITE_URL = process.env.SITE_URL || `http://localhost:${PORT}`;
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_ME_IN_PRODUCTION";
const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY || "";
const PAYSTACK_PUBLIC_KEY = process.env.PAYSTACK_PUBLIC_KEY || "";

fs.mkdirSync(path.join(__dirname, "data"), { recursive: true });
const db = new Database(path.join(__dirname, "data", "store.db"));
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'customer',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS products (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  price INTEGER NOT NULL,
  stock INTEGER NOT NULL DEFAULT 0,
  image_url TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER,
  email TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  phone TEXT NOT NULL DEFAULT '',
  address TEXT NOT NULL DEFAULT '',
  city TEXT NOT NULL DEFAULT '',
  state TEXT NOT NULL DEFAULT '',
  total INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  payment_reference TEXT UNIQUE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL,
  product_id INTEGER NOT NULL,
  product_name TEXT NOT NULL,
  price INTEGER NOT NULL,
  quantity INTEGER NOT NULL,
  FOREIGN KEY(order_id) REFERENCES orders(id)
);
`);

function seed() {
  const count = db.prepare("SELECT COUNT(*) c FROM products").get().c;
  if (count) return;
  const products = [
    ["Classic T-Shirt","Comfortable everyday wear",15000,25,"👕"],
    ["Premium Sneakers","Clean everyday sneakers",45000,15,"👟"],
    ["Everyday Backpack","Simple and practical",28000,20,"🎒"],
    ["Smart Watch","Modern everyday accessory",65000,10,"⌚"],
    ["Classic Cap","Simple casual style",12000,30,"🧢"],
    ["Wireless Earbuds","Compact wireless audio",35000,18,"🎧"],
    ["Travel Bottle","Reusable daily bottle",10000,40,"🥤"],
    ["Minimal Wallet","Slim everyday wallet",18000,25,"👛"]
  ];
  const stmt = db.prepare("INSERT INTO products(name,description,price,stock,image_url) VALUES(?,?,?,?,?)");
  const tx = db.transaction(() => products.forEach(p => stmt.run(...p)));
  tx();
}
seed();

if (process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
  const existing = db.prepare("SELECT id FROM users WHERE email=?").get(process.env.ADMIN_EMAIL.toLowerCase());
  if (!existing) {
    const hash = bcrypt.hashSync(process.env.ADMIN_PASSWORD, 12);
    db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'admin')")
      .run("Store Admin", process.env.ADMIN_EMAIL.toLowerCase(), hash);
  }
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false }));

function sign(user) {
  return jwt.sign({ id:user.id, role:user.role, email:user.email }, JWT_SECRET, { expiresIn:"7d" });
}
function auth(req,res,next) {
  try {
    const h=req.headers.authorization||"";
    if(!h.startsWith("Bearer ")) return res.status(401).json({error:"Authentication required"});
    req.user=jwt.verify(h.slice(7),JWT_SECRET);
    next();
  } catch { res.status(401).json({error:"Invalid or expired session"}); }
}
function admin(req,res,next) {
  if(req.user?.role!=="admin") return res.status(403).json({error:"Admin access required"});
  next();
}
function cleanEmail(email) {
  return String(email||"").trim().toLowerCase();
}
function safeUser(u) { return {id:u.id,name:u.name,email:u.email,role:u.role}; }

app.get("/api/config", (req,res)=>res.json({paystackPublicKey:PAYSTACK_PUBLIC_KEY,siteUrl:SITE_URL}));

app.get("/api/products",(req,res)=>{
  const rows=db.prepare("SELECT id,name,description,price,stock,image_url FROM products WHERE active=1 ORDER BY id DESC").all();
  res.json(rows);
});

app.post("/api/auth/register", async (req,res)=>{
  const name=String(req.body.name||"").trim();
  const email=cleanEmail(req.body.email);
  const password=String(req.body.password||"");
  if(name.length<2 || !email.includes("@") || password.length<8) return res.status(400).json({error:"Enter a valid name, email and password of at least 8 characters."});
  try {
    const hash=await bcrypt.hash(password,12);
    const info=db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'customer')").run(name,email,hash);
    const user=db.prepare("SELECT id,name,email,role FROM users WHERE id=?").get(info.lastInsertRowid);
    res.json({token:sign(user),user:safeUser(user)});
  } catch { res.status(409).json({error:"An account with that email already exists."}); }
});

app.post("/api/auth/login", async (req,res)=>{
  const email=cleanEmail(req.body.email);
  const password=String(req.body.password||"");
  const user=db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if(!user || !(await bcrypt.compare(password,user.password_hash))) return res.status(401).json({error:"Invalid email or password"});
  res.json({token:sign(user),user:safeUser(user)});
});

app.get("/api/me",auth,(req,res)=>{
  const u=db.prepare("SELECT id,name,email,role FROM users WHERE id=?").get(req.user.id);
  res.json(safeUser(u));
});

function cartDetails(items) {
  if(!Array.isArray(items) || !items.length) throw new Error("Cart is empty");
  const normalized=[];
  let total=0;
  for(const item of items) {
    const id=Number(item.product_id), qty=Number(item.quantity);
    if(!Number.isInteger(id) || !Number.isInteger(qty) || qty<1 || qty>99) throw new Error("Invalid cart");
    const p=db.prepare("SELECT id,name,price,stock FROM products WHERE id=? AND active=1").get(id);
    if(!p) throw new Error("Product not found");
    if(qty>p.stock) throw new Error(`Not enough stock for ${p.name}`);
    normalized.push({product_id:p.id,name:p.name,price:p.price,quantity:qty});
    total += p.price*qty;
  }
  return {items:normalized,total};
}

app.post("/api/orders/initialize",auth,async (req,res)=>{
  if(!PAYSTACK_SECRET_KEY) return res.status(500).json({error:"Paystack secret key is not configured"});
  const email=cleanEmail(req.body.email||req.user.email);
  const customerName=String(req.body.customer_name||"").trim();
  const phone=String(req.body.phone||"").trim();
  const address=String(req.body.address||"").trim();
  const city=String(req.body.city||"").trim();
  const state=String(req.body.state||"").trim();
  if(!email.includes("@") || customerName.length<2 || !phone || !address || !city || !state)
    return res.status(400).json({error:"Complete the delivery details before payment."});

  let details;
  try { details=cartDetails(req.body.items); } catch(e) { return res.status(400).json({error:e.message}); }

  const reference=`SG-${Date.now()}-${crypto.randomBytes(4).toString("hex")}`;
  const info=db.prepare(`
    INSERT INTO orders(user_id,email,customer_name,phone,address,city,state,total,status,payment_reference)
    VALUES(?,?,?,?,?,?,?,?,?,?)
  `).run(req.user.id,email,customerName,phone,address,city,state,details.total,"pending",reference);
  const orderId=Number(info.lastInsertRowid);
  const itemStmt=db.prepare("INSERT INTO order_items(order_id,product_id,product_name,price,quantity) VALUES(?,?,?,?,?)");
  const tx=db.transaction(()=>details.items.forEach(i=>itemStmt.run(orderId,i.product_id,i.name,i.price,i.quantity)));
  tx();

  try {
    const response=await fetch("https://api.paystack.co/transaction/initialize",{
      method:"POST",
      headers:{"Authorization":`Bearer ${PAYSTACK_SECRET_KEY}`,"Content-Type":"application/json"},
      body:JSON.stringify({
        email,
        amount:String(details.total*100),
        currency:"NGN",
        reference,
        callback_url:`${SITE_URL}/payment.html`,
        metadata:{order_id:orderId,store:"Singapore Store"}
      })
    });
    const data=await response.json();
    if(!response.ok || !data.status) throw new Error(data.message||"Paystack initialization failed");
    res.json({orderId,reference,accessCode:data.data.access_code});
  } catch(e) {
    db.prepare("UPDATE orders SET status='payment_error' WHERE id=?").run(orderId);
    res.status(502).json({error:e.message});
  }
});

function verifyWithPaystack(reference) {
  return fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,{
    headers:{Authorization:`Bearer ${PAYSTACK_SECRET_KEY}`}
  }).then(r=>r.json());
}

function fulfill(reference, verified) {
  const order=db.prepare("SELECT * FROM orders WHERE payment_reference=?").get(reference);
  if(!order) return {ok:false,error:"Order not found"};
  if(order.status==="paid") return {ok:true,order};
  if(verified.status!=="success") {
    db.prepare("UPDATE orders SET status=? WHERE id=?").run(verified.status||"failed",order.id);
    return {ok:false,error:"Payment was not successful"};
  }
  if(Number(verified.amount)!==order.total*100 || verified.currency!=="NGN") {
    db.prepare("UPDATE orders SET status='amount_mismatch' WHERE id=?").run(order.id);
    return {ok:false,error:"Payment amount mismatch"};
  }
  const items=db.prepare("SELECT * FROM order_items WHERE order_id=?").all(order.id);
  const tx=db.transaction(()=>{
    for(const item of items) {
      const p=db.prepare("SELECT stock FROM products WHERE id=?").get(item.product_id);
      if(!p || p.stock<item.quantity) throw new Error("Insufficient stock during fulfillment");
    }
    for(const item of items) db.prepare("UPDATE products SET stock=stock-? WHERE id=?").run(item.quantity,item.product_id);
    db.prepare("UPDATE orders SET status='paid' WHERE id=?").run(order.id);
  });
  try { tx(); } catch { return {ok:false,error:"Stock changed before payment could be fulfilled"}; }
  return {ok:true,order:db.prepare("SELECT * FROM orders WHERE id=?").get(order.id)};
}

app.post("/api/orders/verify",auth,async (req,res)=>{
  if(!PAYSTACK_SECRET_KEY) return res.status(500).json({error:"Paystack secret key is not configured"});
  const reference=String(req.body.reference||"");
  if(!reference) return res.status(400).json({error:"Missing reference"});
  const result=await verifyWithPaystack(reference);
  if(!result.status) return res.status(400).json({error:result.message||"Could not verify payment"});
  const order=db.prepare("SELECT user_id FROM orders WHERE payment_reference=?").get(reference);
  if(!order || order.user_id!==req.user.id) return res.status(403).json({error:"Order does not belong to this account"});
  const done=fulfill(reference,result.data);
  if(!done.ok) return res.status(400).json({error:done.error});
  res.json({success:true,order:done.order});
});

app.post("/api/paystack/webhook", express.raw({type:"application/json"}), (req,res)=>{
  const signature=req.headers["x-paystack-signature"];
  if(!PAYSTACK_SECRET_KEY || !signature) return res.sendStatus(401);
  const hash=crypto.createHmac("sha512",PAYSTACK_SECRET_KEY).update(req.body).digest("hex");
  if(hash!==signature) return res.sendStatus(401);
  let event;
  try { event=JSON.parse(req.body.toString("utf8")); } catch { return res.sendStatus(400); }
  res.sendStatus(200);
  if(event.event==="charge.success" && event.data?.reference) {
    try { fulfill(event.data.reference,event.data); } catch {}
  }
});

app.get("/api/orders",auth,(req,res)=>{
  const orders=db.prepare("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC").all(req.user.id);
  res.json(orders);
});

app.get("/api/orders/:id",auth,(req,res)=>{
  const order=db.prepare("SELECT * FROM orders WHERE id=? AND user_id=?").get(req.params.id,req.user.id);
  if(!order) return res.status(404).json({error:"Order not found"});
  const items=db.prepare("SELECT * FROM order_items WHERE order_id=?").all(order.id);
  res.json({...order,items});
});

// Admin
app.get("/api/admin/products",auth,admin,(req,res)=>res.json(db.prepare("SELECT * FROM products ORDER BY id DESC").all()));
app.post("/api/admin/products",auth,admin,(req,res)=>{
  const {name,description="",price,stock=0,image_url="",active=1}=req.body;
  if(!name || !Number.isFinite(Number(price))) return res.status(400).json({error:"Name and valid price required"});
  const info=db.prepare("INSERT INTO products(name,description,price,stock,image_url,active) VALUES(?,?,?,?,?,?)")
    .run(String(name).trim(),String(description),Number(price),Number(stock),String(image_url),active?1:0);
  res.json(db.prepare("SELECT * FROM products WHERE id=?").get(info.lastInsertRowid));
});
app.put("/api/admin/products/:id",auth,admin,(req,res)=>{
  const {name,description="",price,stock=0,image_url="",active=1}=req.body;
  db.prepare("UPDATE products SET name=?,description=?,price=?,stock=?,image_url=?,active=? WHERE id=?")
    .run(String(name).trim(),String(description),Number(price),Number(stock),String(image_url),active?1:0,req.params.id);
  res.json(db.prepare("SELECT * FROM products WHERE id=?").get(req.params.id));
});
app.delete("/api/admin/products/:id",auth,admin,(req,res)=>{
  db.prepare("UPDATE products SET active=0 WHERE id=?").run(req.params.id);
  res.json({success:true});
});
app.get("/api/admin/orders",auth,admin,(req,res)=>{
  const orders=db.prepare("SELECT * FROM orders ORDER BY id DESC").all();
  res.json(orders);
});
app.put("/api/admin/orders/:id",auth,admin,(req,res)=>{
  const allowed=["pending","paid","processing","shipped","delivered","cancelled","payment_error","amount_mismatch"];
  if(!allowed.includes(req.body.status)) return res.status(400).json({error:"Invalid status"});
  db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status,req.params.id);
  res.json({success:true});
});

app.use(express.static(path.join(__dirname,"public")));
app.get("*",(req,res)=>{
  if(req.path.startsWith("/api/")) return res.status(404).json({error:"Not found"});
  res.sendFile(path.join(__dirname,"public","index.html"));
});

app.listen(PORT,()=>console.log(`Singapore Store running at ${SITE_URL}`));
